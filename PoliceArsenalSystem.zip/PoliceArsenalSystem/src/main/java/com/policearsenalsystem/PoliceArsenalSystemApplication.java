package com.policearsenalsystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PoliceArsenalSystemApplication {

    public static void main(String[] args) {
        SpringApplication.run(PoliceArsenalSystemApplication.class, args);
    }

}
