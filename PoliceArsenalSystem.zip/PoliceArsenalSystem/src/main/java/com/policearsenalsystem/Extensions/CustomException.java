package com.policearsenalsystem.Extensions;


public class CustomException extends RuntimeException{
    public CustomException(String message) {
        super(message);
    }
}
