package com.policearsenalsystem.Model;

public enum Guntype {
    Revolver,
    Pistol,
    Shotgun,
    Rifle,
    Assault_Rifle,
    Sub_machine_gun,

    Machinegun,
    Automatic,
    Semi_automatic
}
