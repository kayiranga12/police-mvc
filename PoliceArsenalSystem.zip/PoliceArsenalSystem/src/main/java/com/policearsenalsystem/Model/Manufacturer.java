package com.policearsenalsystem.Model;

public enum Manufacturer {
    Glock_19,
    Glock_22,
    Beretta_Model_92,
    Sig_Sauer_P226,
    Heckler_and_Koch_HK45,
    Ruger_LC9,
    Smith_Wesson_M_P_9,
    Remington_870_Shotgun,
    Colt_M4_Carbine,
    Colt_M1911
}
