package com.policearsenalsystem.Model;

public enum Rank {
    INSPECTOR_GENERAL,
    DEPUTY_INSPECTOR_GENERAL,
    CP,
    ACP,

}
